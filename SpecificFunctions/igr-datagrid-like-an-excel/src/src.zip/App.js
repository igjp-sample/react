import DataGridBindingLocalData from './DataGridBindingLocalData.js';
import './App.css';

function App() {
  return (
    <DataGridBindingLocalData/>
  );
}

export default App;
