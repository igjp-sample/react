import { useState, useEffect } from 'react';
import { IgrDataGridModule } from 'igniteui-react-grids';
import { IgrDataGrid } from 'igniteui-react-grids';
import { IgrTextColumn } from 'igniteui-react-grids';
import { IgrGridColumnOptionsModule } from 'igniteui-react-grids';

IgrDataGridModule.register();
IgrGridColumnOptionsModule.register();

function DataGridBindingLocalData() {
    const [data, setData] = useState([]);

    useEffect(() => {
        let lData = [];
        lData.push({ productID: "012021", productName: "Intel CPU" });
        lData.push({ productID: "012022", productName: "AMD CPU" });
        lData.push({ productID: "012023", productName: "Intel Motherboard" });
        lData.push({ productID: "012024", productName: "AMD Motherboard" });
        setData(lData);
    }, []);

    return (
        <IgrDataGrid
            height="500px"
            width="80%"
            autoGenerateColumns="false"
            isColumnOptionsEnabled="true"
            dataSource={data}>
            <IgrTextColumn field="productID" headerText="ID"/>
            <IgrTextColumn field="productName" headerText="name"/>
        </IgrDataGrid>
    );
}

export default DataGridBindingLocalData;